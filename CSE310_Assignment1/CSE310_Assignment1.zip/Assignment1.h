/*	Author: Jan Christian Chavez-Kortlang
*	Student ID: 1202073942
*	Class: CSE310 - Nakamura M/W @ 10:30am
*/

#ifndef ASSIGNMENT1_H
#define ASSIGNMENT1_H

void displayUserOptions();
bool processResponse(char response);
void addCustomerAction();
void displayCustomerAction();
void quitAction();
void removeCustomerAction();
void displayHelp();

#endif